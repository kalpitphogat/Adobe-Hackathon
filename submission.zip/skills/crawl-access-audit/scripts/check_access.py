#!/usr/bin/env python3
"""crawl-access-audit: can an (AI) crawler get in and index the site?
Reads the shared cache and emits findings. Usage: check_access.py <cache_dir>"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(HERE, "..", "..", "audit-orchestrator", "scripts")))
import auditlib as A  # noqa: E402

SKILL = "crawl-access-audit"


def run(cache_dir):
    meta = A.load_meta(cache_dir)
    pages = meta["pages"]
    findings = []
    robots = meta["robots"]

    # 1. robots.txt presence
    if not robots["present"]:
        findings.append(A.finding(
            "No robots.txt found",
            "low",
            f"GET {meta['site']}/robots.txt returned status {robots['status']}.",
            "Add a robots.txt that allows crawling and points to your sitemap; absence "
            "forces every crawler to guess and slows discovery.",
            "low", "crawl-access"))

    # 2. AI crawlers blocked
    blocked_bots = [b for b, s in robots.get("ai_bots", {}).items() if s == "blocked"]
    if blocked_bots:
        key = [b for b in blocked_bots if b in ("GPTBot", "OAI-SearchBot", "ClaudeBot",
                                                "PerplexityBot", "Google-Extended")]
        sev = "critical" if key else "high"
        findings.append(A.finding(
            "AI assistant crawlers are blocked in robots.txt",
            sev,
            f"robots.txt disallows: {', '.join(blocked_bots)}. These are the fetchers "
            "AI assistants use to find and cite pages.",
            "If you want the brand cited by AI assistants, allow these user-agents "
            "(GPTBot, OAI-SearchBot, ClaudeBot, PerplexityBot, Google-Extended) for public content.",
            sev, "crawl-access", checked=len(robots.get("ai_bots", {}))))

    # 3. sitemap
    if not meta["sitemaps"]:
        findings.append(A.finding(
            "No XML sitemap discovered",
            "medium",
            "No sitemap referenced in robots.txt and /sitemap.xml did not return a valid urlset.",
            "Publish an XML sitemap and reference it in robots.txt so crawlers can find "
            "every page without relying on internal-link discovery.",
            "medium", "crawl-access"))

    # 4. per-page blocking / noindex / status
    noindex_pages, blocked_pages, err_pages = [], [], []
    for p in pages:
        xrt = (p.get("x_robots_tag") or "").lower()
        if "noindex" in xrt:
            noindex_pages.append(p["url"])
        if p.get("robots_blocked"):
            blocked_pages.append(p["url"])
        if p["status"] and p["status"] >= 400:
            err_pages.append(f"{p['url']} ({p['status']})")

    # meta robots noindex needs the raw HTML
    meta_noindex = []
    for p in pages:
        html = A.read_page(cache_dir, p, "html") or ""
        low = html.lower()
        if 'name="robots"' in low and "noindex" in low.split('name="robots"', 1)[1][:200]:
            meta_noindex.append(p["url"])
    noindex_pages = sorted(set(noindex_pages) | set(meta_noindex))

    if noindex_pages:
        home_hit = any(u.rstrip("/") == meta["site"] for u in noindex_pages)
        sev = "critical" if home_hit else "high"
        findings.append(A.finding(
            "Pages carry a noindex directive",
            sev,
            f"{len(noindex_pages)}/{len(pages)} crawled pages set noindex "
            f"(meta robots or X-Robots-Tag): {', '.join(noindex_pages[:5])}.",
            "Remove noindex from pages you want found and cited. noindex tells every "
            "engine and assistant to exclude the page entirely.",
            sev, "crawl-access", checked=len(pages)))

    if blocked_pages:
        findings.append(A.finding(
            "Crawlable content is disallowed by robots.txt",
            "high",
            f"{len(blocked_pages)}/{len(pages)} sampled URLs are Disallow'd for the default "
            f"user-agent: {', '.join(blocked_pages[:5])}.",
            "Relax robots.txt Disallow rules for public pages you want indexed and cited.",
            "high", "crawl-access", checked=len(pages)))

    if err_pages:
        findings.append(A.finding(
            "Pages return error status codes",
            "high",
            f"{len(err_pages)} sampled URL(s) returned 4xx/5xx: {', '.join(err_pages[:5])}.",
            "Fix broken URLs (or 301 them to live equivalents). Error pages cannot be "
            "indexed and waste crawl budget.",
            "high", "crawl-access", checked=len(pages)))

    # 5. canonical hygiene
    no_canonical = [p["url"] for p in pages if p["status"] == 200 and not p.get("canonical")]
    if no_canonical and len(no_canonical) == len([p for p in pages if p["status"] == 200]):
        findings.append(A.finding(
            "No canonical URLs declared",
            "low",
            f"0/{len(no_canonical)} successful pages declare rel=canonical.",
            "Add a self-referential rel=canonical to each page to consolidate duplicate/"
            "parameterized URLs onto one authoritative address.",
            "low", "crawl-access", checked=len(no_canonical)))

    # 6. HTTPS
    if meta["site"].startswith("http://"):
        findings.append(A.finding(
            "Site is served over HTTP, not HTTPS",
            "high",
            f"Base URL resolved to {meta['site']}.",
            "Serve everything over HTTPS with a valid certificate; insecure origins are "
            "down-ranked and distrusted by crawlers and assistants.",
            "high", "crawl-access"))

    # 7. Broken internal links
    broken = [lc for lc in meta.get("link_check", [])
              if lc["status"] is None or lc["status"] >= 400]
    if broken:
        sample = ", ".join(f"{lc['url']} ({lc['status']})" for lc in broken[:5])
        findings.append(A.finding(
            "Broken internal links from the homepage",
            "medium",
            f"{len(broken)}/{len(meta.get('link_check', []))} sampled homepage links return "
            f"an error or no response: {sample}.",
            "Fix or redirect broken links. Dead links waste crawl budget, break the path "
            "crawlers use to discover pages, and erode visitor trust.",
            "medium", "crawl-access", checked=len(meta.get("link_check", []))))

    # 8. Mixed content (http sub-resources on an https page)
    mixed = [p["url"] for p in pages if p.get("n_mixed_content", 0) > 0]
    if mixed:
        findings.append(A.finding(
            "Mixed content: insecure resources on secure pages",
            "medium",
            f"{len(mixed)}/{len(pages)} pages reference http:// sub-resources from an https "
            f"page: {', '.join(mixed[:4])}.",
            "Load all scripts, styles, images, and fonts over https. Browsers block or warn "
            "on mixed content, breaking layout and signalling an insecure page.",
            "medium", "crawl-access", checked=len(pages)))

    # 8b. Edge/CDN blocks the AI crawler even though robots.txt allows it
    rb = meta.get("ai_bot_reachability", {})
    if rb.get("blocked"):
        findings.append(A.finding(
            "AI crawler blocked at the edge (CDN/WAF), not in robots.txt",
            "critical",
            f"Homepage returned {rb.get('reference_status')} to a normal browser but "
            f"{rb.get('ai_status')} to the {rb.get('ua')} user-agent — an edge/CDN/WAF rule is "
            "refusing the AI crawler regardless of what robots.txt permits.",
            "Allow-list the AI assistant user-agents (GPTBot, ClaudeBot, PerplexityBot, "
            "OAI-SearchBot, Google-Extended) at your CDN/WAF (Cloudflare, Akamai, Vercel). "
            "robots.txt permission is moot if the edge returns 403 to the bot.",
            "critical", "crawl-access"))

    # 9. llms.txt (emerging AI-assistant guidance file) — proactive improvement
    if not meta.get("llms_txt", {}).get("present"):
        findings.append(A.finding(
            "No llms.txt guidance file for AI assistants",
            "low",
            f"GET {meta['site']}/llms.txt returned status "
            f"{meta.get('llms_txt', {}).get('status')}.",
            "Consider adding an llms.txt (an emerging convention) that points AI assistants to "
            "your most important, quotable pages in plain markdown — a proactive discoverability "
            "signal even though it is not yet universally consumed.",
            "low", "crawl-access"))

    return findings


if __name__ == "__main__":
    A.emit(SKILL, run(sys.argv[1]))
